package org.ie.realworld;

public class KeyBoard {
  private String companyName;
  private String model;
  private int noOfKeys;
  private String type;
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public int getNoOfKeys() {
	return noOfKeys;
}
public void setNoOfKeys(int noOfKeys) {
	this.noOfKeys = noOfKeys;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
  public void pressKey() {}
  public void replaceKey() {}
  
}
