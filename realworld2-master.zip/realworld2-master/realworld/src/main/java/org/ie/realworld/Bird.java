package org.ie.realworld;

public class Bird {
   private int wings;
   private String color;
   private int legs;
public int getWings() {
	return wings;
}
public void setWings(int wings) {
	this.wings = wings;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
public int getLegs() {
	return legs;
}
public void setLegs(int legs) {
	this.legs = legs;
}
   
   public void fly() {}
   public void eat() {}
}
